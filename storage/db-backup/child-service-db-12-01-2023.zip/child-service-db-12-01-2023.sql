-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: 134.119.217.113    Database: shm
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_01_02_090614_create_mst_author_table',2),(6,'2023_01_02_090711_create_mst_books_table',3),(7,'2023_01_10_144517_create_login_history_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_author`
--

DROP TABLE IF EXISTS `mst_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mst_author` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_author`
--

LOCK TABLES `mst_author` WRITE;
/*!40000 ALTER TABLE `mst_author` DISABLE KEYS */;
/*!40000 ALTER TABLE `mst_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_books`
--

DROP TABLE IF EXISTS `mst_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mst_books` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_books`
--

LOCK TABLES `mst_books` WRITE;
/*!40000 ALTER TABLE `mst_books` DISABLE KEYS */;
/*!40000 ALTER TABLE `mst_books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Shamim Reza','opt.shamim@gmail.com',NULL,'$2y$10$eoJr4oqh.ariXpTKrE/PWOYOmTSQIn8tNFwGTajTo/ZKjj9dxHwKC',NULL,'2022-12-13 00:51:15','2022-12-13 00:51:15'),(2,'Shahin','msreza901@gmail.com',NULL,'$2y$10$gATTCFbX2DBslUHcbvLhY.t9eQoEqIS8RJ5lBvzU2QtAwJyyRiMh6',NULL,'2022-12-14 00:57:28','2022-12-14 00:57:28'),(3,'Mou','mou@gmail.com',NULL,'$2y$10$R0OdwvEYOrEGfN/wVq0hBeGSWqLNNHrqcqAQNVnLE9ZhDLAFeaofi',NULL,'2022-12-14 00:59:04','2022-12-14 00:59:04'),(4,'Mahbuba','mahbuba@gmail.com',NULL,'$2y$10$oifgGrJjKlbOgOGsLA6g3OF3o4.6JhebYB4d6DbsX/IxB1NfJPbj6',NULL,'2022-12-14 00:59:46','2022-12-14 00:59:46'),(5,'2GuqZYuM54','Yhb5Xi5YW7@gmail.com',NULL,'$2y$10$A5BxKpKA0hCe38ekT.wPYuZKHLjHYbVSYkv8AG.4XS3Y8vCk23Vzm',NULL,NULL,NULL),(6,'lVpiRBvzp9','C30nlNjMCX@gmail.com',NULL,'$2y$10$N9ct.VWX.uwMk5CHvtUQO.XuQ3k1Jz4av0p3oSELGuZSYYGRNVy/G',NULL,NULL,NULL),(7,'Marcos Swaniawski','nhayes@example.net','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','8yVtPegRAD','2022-12-29 08:55:46','2022-12-29 08:55:46'),(8,'Marie Becker','schneider.clovis@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Z9PWn19u1Q','2022-12-29 08:55:47','2022-12-29 08:55:47'),(9,'Myra Collier','xboyle@example.net','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','hgcVcG33e9','2022-12-29 08:55:48','2022-12-29 08:55:48'),(10,'Theo Tillman','dakota.quitzon@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','JopfK1U2ez','2022-12-29 08:55:48','2022-12-29 08:55:48'),(11,'Prof. Jessy Towne','pedro.feeney@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Hku0mxFQrn','2022-12-29 08:55:49','2022-12-29 08:55:49'),(12,'Hayley Rice','wkuhlman@example.net','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','jAGndRN6yj','2022-12-29 08:55:49','2022-12-29 08:55:49'),(13,'Elwin Beier','armani.bernhard@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','naoeg9eIex','2022-12-29 08:55:49','2022-12-29 08:55:49'),(14,'Lynn Abbott PhD','hildegard26@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','OIoGkBk9ud','2022-12-29 08:55:50','2022-12-29 08:55:50'),(15,'Abigayle Predovic','penelope.jones@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','y2mm5XVDQL','2022-12-29 08:55:50','2022-12-29 08:55:50'),(16,'Monroe Boehm','anderson.lamont@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','67zzVMV3q7','2022-12-29 08:55:50','2022-12-29 08:55:50'),(17,'Jalyn McKenzie','denesik.murphy@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','TRG6Y632EY','2022-12-29 08:55:51','2022-12-29 08:55:51'),(18,'Marcelina Bernhard','djohnston@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','UVgIzKUoVH','2022-12-29 08:55:51','2022-12-29 08:55:51'),(19,'Alverta Rempel','kariane.anderson@example.net','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','rCkbEOTKrr','2022-12-29 08:55:52','2022-12-29 08:55:52'),(20,'Dr. Alberto Monahan I','geoffrey.fay@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','71wo2Vz9lW','2022-12-29 08:55:52','2022-12-29 08:55:52'),(21,'Yessenia Collier','wbradtke@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Vw14lbCQSS','2022-12-29 08:55:52','2022-12-29 08:55:52'),(22,'Mrs. Serena Simonis III','brisa.mitchell@example.net','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','ZPwvrpapFd','2022-12-29 08:55:53','2022-12-29 08:55:53'),(23,'Adella Wilderman','leonard98@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','LvVjWOPmBi','2022-12-29 08:55:53','2022-12-29 08:55:53'),(24,'Hattie Howe','jess33@example.net','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','hcYR1sKwk9','2022-12-29 08:55:53','2022-12-29 08:55:53'),(25,'Erin McCullough','trevion.hyatt@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','dxU4IicfqO','2022-12-29 08:55:54','2022-12-29 08:55:54'),(26,'Allen Kulas','streich.louisa@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','6Stmaz5M8X','2022-12-29 08:55:54','2022-12-29 08:55:54'),(27,'Ayden Miller','rico.strosin@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','7e6CLwxlkc','2022-12-29 08:55:55','2022-12-29 08:55:55'),(28,'Raina Hartmann','quincy.johns@example.org','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','IECGe50vaC','2022-12-29 08:55:55','2022-12-29 08:55:55'),(29,'Dr. Erik Rutherford','alexa.pollich@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Q2dxB7ft3Z','2022-12-29 08:55:55','2022-12-29 08:55:55'),(30,'Rosalee Trantow','evans10@example.com','2022-12-29 08:55:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','2ud690b6Xh','2022-12-29 08:55:56','2022-12-29 08:55:56'),(31,'Adelia Hammes I','marilyne.oreilly@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','sWzMBBTVuU','2022-12-29 08:55:56','2022-12-29 08:55:56'),(32,'Miss Gwen Legros II','rblock@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','BLvxgfY7H3','2022-12-29 08:55:56','2022-12-29 08:55:56'),(33,'Terence O\'Reilly','cassin.dayton@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','tiRH3aPKr7','2022-12-29 08:55:57','2022-12-29 08:55:57'),(34,'Samson Sauer','lyda19@example.net','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','EbW8pk7Xgk','2022-12-29 08:55:57','2022-12-29 08:55:57'),(35,'Mya Roob','stracke.berneice@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','PRHkQgJgMc','2022-12-29 08:55:58','2022-12-29 08:55:58'),(36,'Kirk Hettinger','leopoldo90@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','bZ8NT6Hdli','2022-12-29 08:55:58','2022-12-29 08:55:58'),(37,'Leanna Schmidt','ivon@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','A5ybPq84EI','2022-12-29 08:55:58','2022-12-29 08:55:58'),(38,'Mrs. Emelia Toy','nvon@example.net','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','DuHADp5FdK','2022-12-29 08:55:59','2022-12-29 08:55:59'),(39,'Cleve Gerhold','gjast@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','0W12XH3DQ1','2022-12-29 08:55:59','2022-12-29 08:55:59'),(40,'Lukas Schimmel','fadel.aniyah@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','sMSey5zdWY','2022-12-29 08:55:59','2022-12-29 08:55:59'),(41,'Micah Zieme IV','nyasia.schuster@example.net','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','IKOtDCnwlR','2022-12-29 08:56:00','2022-12-29 08:56:00'),(42,'Delphine Conroy Jr.','brandy.predovic@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','98wl78KzxA','2022-12-29 08:56:00','2022-12-29 08:56:00'),(43,'Prof. Constantin Fritsch DDS','jasen.vonrueden@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','N6g7vIv4NC','2022-12-29 08:56:01','2022-12-29 08:56:01'),(44,'Herman Franecki Jr.','christine.mohr@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','WjR5OzISIt','2022-12-29 08:56:01','2022-12-29 08:56:01'),(45,'Elsa Simonis','ofeeney@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','G3psa6kUg4','2022-12-29 08:56:01','2022-12-29 08:56:01'),(46,'Mrs. Bianka Kunze','nschuppe@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mMTUIUYVH3','2022-12-29 08:56:02','2022-12-29 08:56:02'),(47,'Miss Kavon Thompson Sr.','alubowitz@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','ndIJe8Js5u','2022-12-29 08:56:02','2022-12-29 08:56:02'),(48,'Samanta Bednar','xpadberg@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','4H8OWsUFiT','2022-12-29 08:56:02','2022-12-29 08:56:02'),(49,'Dariana Harber IV','bspinka@example.net','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','WTeMpShnWa','2022-12-29 08:56:03','2022-12-29 08:56:03'),(50,'Florine Lind','franecki.wilmer@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','bNuuuq9IuV','2022-12-29 08:56:03','2022-12-29 08:56:03'),(51,'Cathryn Cummerata','forest.hahn@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','DdOTkfemTv','2022-12-29 08:56:04','2022-12-29 08:56:04'),(52,'Prof. Demarcus Collier','jerald45@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','IVHRTDvhLu','2022-12-29 08:56:04','2022-12-29 08:56:04'),(53,'Mrs. Millie Lehner I','cormier.ashlynn@example.com','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','BGLuRIxlBz','2022-12-29 08:56:04','2022-12-29 08:56:04'),(54,'Alvena Ward','linnie66@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mtuY0EGpIw','2022-12-29 08:56:05','2022-12-29 08:56:05'),(55,'Annette Bins','milton.hermiston@example.org','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','7f4eU0n5gg','2022-12-29 08:56:05','2022-12-29 08:56:05'),(56,'Felton Johns','cade67@example.net','2022-12-29 08:55:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','a8D3QNuz2D','2022-12-29 08:56:05','2022-12-29 08:56:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-12 17:09:14
